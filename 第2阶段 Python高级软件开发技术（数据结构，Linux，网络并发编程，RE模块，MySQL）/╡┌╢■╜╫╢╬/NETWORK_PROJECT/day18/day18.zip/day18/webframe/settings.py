"""
web frame 部分的配置文件
"""

# [frame address]
frame_ip = '127.0.0.1'
frame_port = 8080

# [debug]
DEBUG = True

# [static]
STATIC_DIR = "./static"