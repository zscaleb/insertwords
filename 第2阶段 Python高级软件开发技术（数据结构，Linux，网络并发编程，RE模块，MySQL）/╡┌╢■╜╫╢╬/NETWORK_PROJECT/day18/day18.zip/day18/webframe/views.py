"""
数据处理的具体函数
"""
import time

def show_time():
    return time.ctime()

def guonei():
    return "你看到了国内新闻"

def guoji():
    return "你看到了国际新闻"